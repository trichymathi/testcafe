// Class And Methods

// Syntax Of Class
// class className{
//     type methods
// }

// Syntax Of Methods
// nameOfMethod(){
// }

// Refer Helper/printHelper.js

// way of creation 1
import { CustomerDetails } from "./Helper/printHelper.js";

 var customerDetails = new CustomerDetails() // Creating Instance like object in java
 customerDetails.printFirstName("Mathi")
 customerDetails.printLastName("Maran")

 // way of creation 2 ( This Type will bw clean and clear object instance will 
 // have an export other than class)
 import { vehicleName } from "./Helper/printHelper.js";

vehicleName.printBikeName("Himalayan")
vehicleName.printCarName("Tata")

