// Relational or comparison operators

// > - more than
// < - less than
// >= - more than equal
// <= - less than equal

var results = 4>5
console.log(results)

// Equality Operator

var x = 1;

console.log(x == '1') // Output :- true 
// ? (loose comparison - it just check whether left side and right side is same 
// it will not check the datatype) 
console.log(x === '1') // Output :- false
// ? (strict comparison - it will check both the datatype and values) 

