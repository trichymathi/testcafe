// Concatination & Interpolation
var price = 10
var nameOfItem = "Cup"
// Concatination
var messageToPrint = "The price for your "+nameOfItem+" is "+price+" dollars" 
// Interpolation (we need to use symbol ` which is below escape button)
var messageToPrint2 = `The price for your ${nameOfItem} is ${price} dollars` 
console.log(messageToPrint)
console.log(messageToPrint2)