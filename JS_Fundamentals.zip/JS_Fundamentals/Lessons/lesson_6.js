// Conditional Statement

// if(condition){
//     // execute some code here
// }else{
//     // exwcute some code here
// }

// If hour between 6 to 12 print "Good Morning"
// If hour between 12 to 18 print "Good Afternoon"
// Otherwise : Good Evening

var hour =17

if(hour >= 6 && hour < 12){
    console.log("Good Morning")
} else if(hour >= 12 && hour < 18){
    console.log("Good Afternoon")
}else{
    console.log("Good Evening")
}

var ageMoreThanEighteen = true
var isUSPerson = false

if(ageMoreThanEighteen && isUSPerson){
    console.log("Eligible for DL")
}else{
   console.log("Not Eligible for DL") 
}
