// Logical Operator 

// Logical "AND"
console.log(true && false) // all values have to be TRUE for the expression to be TRUE

// Logical "OR"
console.log(true || false) // any value should be TRUE for the expression to be TRUE

// Use Case 
var ageMoreThanEighteen = true
var isUSPerson = false
var eligibilityForDrivingLicense = ageMoreThanEighteen && isUSPerson
console.log("The Person is eligible foe DL : "+ eligibilityForDrivingLicense)

// Logical "NOT"
console.log(!true)
console.log(6 !== 10)

