// Hello World!
console.log("Hello World!")

// Variables
var firstName = "Mathi"
let lastName = "Maran"
console.log(lastName)

var age, dateOfBirth, sex
age = "10"
sex = "Male"
console.log(age)
age = "12" // Overriding Age
console.log(age)

// Constants (Here we not able to override It will thorw error)
const occupation = "Engineer" 
// we cannot use const as like how we used in var age,dateOfBirth
// const' declarations must be initialized in begining itself
console.log(occupation)

// Datatypes
var middleName = "Maran" // String
var ageOfBrother = 10 //Number
var isHeMarried = false  //boolean
var yearsInMarriage = null //null
var numberOfCars = undefined //undefiend