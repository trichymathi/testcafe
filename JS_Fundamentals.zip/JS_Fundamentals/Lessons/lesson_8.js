// Functions -> Is like methods in Java

// Declarative Function
helloOne()  // calling the function before function created
function helloOne(){
    console.log("Hello One!")
}

//helloOne() calling the function after function created

// Anonymus Function
var helloTwo = function(){
    console.log("Hello Two!")
}
helloTwo()

// Difference between both function is in Declarative function we can call the function
// Before the function creation in Anonymus function it will not supported

// ES6 function syntax or arrow function
var helloThree = () => {
    console.log("Hello Three!")
}
helloThree()


// Functions With Arguments
function printName(firstName,lastName){
    console.log(`${firstName} ${lastName}`) // Here We using interpolation concept
}

// Functions With Return type
function multiplyByTwo(number){
   var result = number*2
   return result
}
var myResult=multiplyByTwo(10)
console.log(myResult) 
//console.log(multiplyByTwo(20))


// Refer Helper/printHelper.js
// import function (Befor Using import we need to update 
// the package.json with type:"module")
// import { functionName } from "../location"
import { printAge } from "../Lessons/Helper/printHelper.js"
printAge(10)

// import every function
// import * as objectName(you can give any name) from "../location"
import * as Helper from "../Lessons/Helper/printHelper.js"
Helper.printAge(20)

