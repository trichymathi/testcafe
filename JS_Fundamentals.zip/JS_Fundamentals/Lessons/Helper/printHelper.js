// if you want to import to any page we need to use export key before the function

export function printAge(age){
    console.log("The age from helper is "+ age)
}

// way of creation 1 (class will have an export so that it can call anywhere)
export class CustomerDetails{

    //put /** and click enterit will help to comment for methods
    /**
     * This will print first name
     * @param {string} firstName 
     */
    printFirstName(firstName){
        console.log(firstName)
    }

    printLastName(lastName){
        console.log(lastName)
    }
}

// way of creation 2 (Here class instance will have an export so that we can call)
class VehicleName{

    printBikeName(bikeName){
        console.log(bikeName)
    }

    printCarName(carName){
        console.log(carName)
    }
}

export const vehicleName = new VehicleName()