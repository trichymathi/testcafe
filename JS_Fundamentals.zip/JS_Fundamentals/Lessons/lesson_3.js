// Objects 
// (To Hold Multiple Values and Variables Inside the datatype for that we need objects)
// This will act like method inside the class how we calling with the help of object in java
// Here we can use key and value pair
var customer = {
    firstName: 'Mathi',
    lastName : 'Maran'
}

console.log(customer) // Output :- { firstName: 'Mathi', lastName: 'Maran' }
// Calling The Variables Using Dot Notation
console.log(customer.firstName) // Output :- Mathi
console.log(customer.lastName) // Output :- Maran

// Another Form Of Calling The Variables Inside Bracket Notation
console.log(customer['firstName'])
console.log(customer['lastName'])

// Changing The Values Using Dot Notation
customer.firstName = "Hari"

// Changing The Values Using Bracket Notation
customer['lastName'] = "Haran"

// Calling the values using interpolation
console.log(`${customer.firstName} ${customer.lastName}`)


// Arrays
var cars =["Volvo","Tata","Maruthi"]

// To Call the values in the array
console.log(cars[0])

// To Update the values in the array
cars[0] = "Huyndai"
console.log(cars[0])

// Also We can able to store the array in object
var customers = {
    firstName: 'Mathi',
    lastName : 'Maran',
    cars : ["Volvo","Tata","Maruthi"] // Storing array in objects
}

console.log(customers.cars[1])